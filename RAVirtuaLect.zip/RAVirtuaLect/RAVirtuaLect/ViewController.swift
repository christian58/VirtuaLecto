//
//  ViewController.swift
//  RAVirtuaLect
//
//  Created by virtual lecto on 5/14/19.
//  Copyright © 2019 virtual lecto. All rights reserved.
//

import UIKit
import FirebaseAuth

class ViewController: UIViewController {

    @IBOutlet weak var logoPrincipal: UIImageView!
    

    
    @IBOutlet weak var emailTextField: UITextField!
    
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    
    //END LOGIN
    
    //REGISTER
    
    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var apellidoTextField: UITextField!
    
    @IBOutlet weak var emailRegisterTextField: UITextField!
    
    @IBOutlet weak var passRegTextField: UITextField!
    
    @IBOutlet weak var passconfRegTextField: UITextField!
    
    //END REGISTER

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
//   var  tam = logoPrincipal.draw(CGRect( 400,200))
        // Do any additional setup after loading the view, typically from a nib.
    }

    
 
    @IBAction func signInButtonTapped(_ sender: UIButton) {
        
        if let email = emailTextField.text, let pass = passwordTextField.text{
            
            
           
                Auth.auth().signIn(withEmail: email, password: pass) { (user, error) in
                    
                    if let u = user{
                        self.performSegue(withIdentifier: "goToHome", sender: self)
                    }
                    else{
                        
                    }
                    
                }
            
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        emailTextField.resignFirstResponder()
        passwordTextField.resignFirstResponder()
    }
    

    
    
    
    @IBAction func goToRegister(_ sender: UIButton) {
       
      
        self.performSegue(withIdentifier: "goToRegister", sender: self)
    }
    
    
    @IBAction func clickRegister(_ sender: UIButton) {
        if let email = emailRegisterTextField.text, let pass = passRegTextField.text, let passconf = passconfRegTextField.text{
            
            //if passconf == pass{
                
            //}
            Auth.auth().createUser(withEmail: email, password: pass) { (user, error) in
                if let u = user{
                    self.performSegue(withIdentifier: "goToHome2", sender: self)
                }
                else{
                    
                }
            }
                
            
        }
        
    }
    

    
    @IBAction func clickCancel(_ sender: UIButton) {
        self.performSegue(withIdentifier: "goToInit", sender: self)
    }
    
}

